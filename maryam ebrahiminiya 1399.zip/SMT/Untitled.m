clc;
clear all;
close all;
X=imread('02.jpg');
imfinfo('02.jpg')
figure,imshow(X)
b = imresize(X,[200,200]);
si = size(b,10);
sj = size(b,20);
figure;imshow(b);
% Binarization
th = graythresh(b);
I = im2bw(b,th);
w = 300;
h = 100;
c=si/w;
r=sj/h;
kl=bwmorph(~I,'thin',inf);
figure,imshow(kl)
R(:,:)=kl(:,:);
I=1;
U1=w;
J=1;
U2=h;
E=1;
for i=1:r
  for j=1:c
B(I:U1,J:U2)=R(I:U1,J:U2);
[x,y]=find(B==1);
CX=mean(x);
CY=mean(y);
CXX(E)=CX;
CYY(E)=CY;
T(I:U1,J:U2)=B(I:U1,J:U2);
J=J+w;
U2=U2+h;
E=E+1;
clear B x y    
    end
I=I+w;
U1=U1+h;
J=1;
U2=h;
end
hold on
imshow(R)

%plot(CYY,CXX,'.c')
hold on



hold on
imshow(R)
image(x)
image([300 400], [300 400],R);
hold on
hold off

